import { useRef, useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronUp, ChevronDown, AlertTriangle } from 'lucide-react';
import { AccountRow } from './account-row';
import { SavedCollapsedCard } from '@/components/ui/saved-collapsed-card';

interface NegativeAccountsSectionProps {
  creditData: any;
  aiViolations: { [accountId: string]: string[] };
  disputeReasons: any;
  disputeInstructions: any;
  onDisputeSaved: (accountId: string, disputeData: any) => void;
  onDisputeReset: (accountId: string) => void;
  aiScanCompleted: boolean;
  savedDisputes: { [accountId: string]: boolean | { reason: string; instruction: string; violations?: string[] } };
  showNegativeAccounts: boolean;
  setShowNegativeAccounts: (show: boolean) => void;
  expandAll: boolean;
  setExpandAll: (expand: boolean) => void;
  showAllDetails: boolean;
  setShowAllDetails: (show: boolean) => void;
  negativeAccountsCollapsed: boolean;
  setNegativeAccountsCollapsed: (collapsed: boolean) => void;
  showCreditAccounts: boolean;
  userHasManuallyExpanded: boolean;
  setUserHasManuallyExpanded: (expanded: boolean) => void;
  showRedOnNegativeAccounts?: boolean;
}

export default function NegativeAccountsSection({
  creditData,
  aiViolations,
  disputeReasons,
  disputeInstructions,
  onDisputeSaved,
  onDisputeReset,
  aiScanCompleted,
  savedDisputes,
  showNegativeAccounts,
  setShowNegativeAccounts,
  expandAll,
  setExpandAll,
  showAllDetails,
  setShowAllDetails,
  negativeAccountsCollapsed,
  setNegativeAccountsCollapsed,
  showCreditAccounts,
  userHasManuallyExpanded,
  setUserHasManuallyExpanded,
  showRedOnNegativeAccounts = false,
}: NegativeAccountsSectionProps) {
  const negativeAccountsRef = useRef<HTMLDivElement>(null);
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({});


  // Function to determine if an account is negative
  const isNegativeAccount = (account: any) => {
    // 1. Check derogatory data indicator
    if (account['@_DerogatoryDataIndicator'] === 'Y') {
      return true;
    }

    // 2. Check for collection accounts
    if (account['@IsCollectionIndicator'] === 'true' || account['@IsCollectionIndicator'] === 'Y') {
      return true;
    }

    // 3. Check for charge-off accounts
    if (account['@IsChargeoffIndicator'] === 'true' || account['@IsChargeoffIndicator'] === 'Y') {
      return true;
    }

    // 4. Check for past due amounts (indicates late payments)
    const pastDue = parseInt(account['@_PastDueAmount'] || '0');
    if (pastDue > 0) {
      return true;
    }

    // 5. Check current rating code for late payments (2-9 indicate late payments)
    const currentRating = account._CURRENT_RATING?.['@_Code'];
    if (currentRating && ['2', '3', '4', '5', '6', '7', '8', '9'].includes(currentRating)) {
      return true;
    }

    // 6. Check for charge-off date
    if (account['@_ChargeOffDate']) {
      return true;
    }

    return false;
  };

  // Get negative accounts data
  const accounts = creditData?.CREDIT_RESPONSE?.CREDIT_LIABILITY || [];
  const negativeAccounts = accounts.filter((account: any) => isNegativeAccount(account));

  // Compute summary text for saved disputes
  const totalSavedDisputes = negativeAccounts.filter((account: any) => {
    const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
    return savedDisputes[accountId];
  }).length;
  const summaryText = `You've saved disputes for ${totalSavedDisputes} negative account(s) across TransUnion, Equifax, and Experian.`;

  // Check if all negative accounts have saved disputes
  const allNegativeAccountsSaved = negativeAccounts.length > 0 && negativeAccounts.every((account: any) => {
    const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
    return savedDisputes[accountId];
  });

  // Check if there are any unsaved negative accounts (for red warning styling)
  const hasUnsavedNegativeAccounts = negativeAccounts.length > 0 && negativeAccounts.some((account: any) => {
    const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
    return !savedDisputes[accountId];
  });

  return (
    <div ref={negativeAccountsRef}>
      {negativeAccountsCollapsed ? (
        allNegativeAccountsSaved ? (
          <SavedCollapsedCard
            sectionName="Negative Accounts"
            successMessage="Negative Accounts – Disputes Saved"
            summaryText={summaryText}
            onExpand={() => {
              setNegativeAccountsCollapsed(false);
              setShowNegativeAccounts(true);
              setUserHasManuallyExpanded(true);
            }}
          />
        ) : (
          <Card className={`rounded-lg transition-all duration-300 hover:shadow-lg ${
            hasUnsavedNegativeAccounts 
              ? 'border-2 border-red-500 bg-red-50' 
              : 'border border-gray-200 bg-white'
          }`}>
            <CardHeader
              className={`cursor-pointer transition-colors duration-200 rounded-lg min-h-[72px] flex items-center ${
                hasUnsavedNegativeAccounts 
                  ? 'hover:bg-red-100' 
                  : 'hover:bg-gray-50'
              }`}
              onClick={() => {
                setNegativeAccountsCollapsed(false);
                setShowNegativeAccounts(true);
                setUserHasManuallyExpanded(true);
              }}
            >
              <div className="flex justify-between items-center w-full">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                    hasUnsavedNegativeAccounts ? 'bg-red-500' : 'gauge-red'
                  }`}>
                    {negativeAccounts.length}
                  </div>
                  <div>
                    <h3 className={`text-lg font-bold ${
                      hasUnsavedNegativeAccounts ? 'text-red-700' : 'text-gray-900'
                    }`}>Negative Accounts</h3>
                    <p className={`text-sm flex items-center gap-1 font-normal ${
                      hasUnsavedNegativeAccounts ? 'text-red-700' : 'text-red-600'
                    }`}>
                      <AlertTriangle className="w-4 h-4" />
                      {negativeAccounts.length} negative accounts need dispute review
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <span className={`text-sm ${
                    hasUnsavedNegativeAccounts ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {negativeAccounts.length} accounts
                  </span>
                  <ChevronDown className={`w-4 h-4 ${
                    hasUnsavedNegativeAccounts ? 'text-red-600' : 'text-gray-600'
                  }`} />
                </div>
              </div>
            </CardHeader>
          </Card>
        )
      ) : (
        <Card
          className="transition-all duration-300 overflow-hidden"
        >
          <CardHeader
            className={`cursor-pointer transition-colors duration-200 min-h-[72px] flex items-center ${
              hasUnsavedNegativeAccounts && !showNegativeAccounts 
                ? 'hover:bg-red-100' 
                : 'hover:bg-gray-50'
            }`}
            onClick={() => setShowNegativeAccounts(!showNegativeAccounts)}
          >
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                  hasUnsavedNegativeAccounts && !showNegativeAccounts ? 'bg-red-500' : 'gauge-red'
                }`}>
                  {negativeAccounts.length}
                </div>
                <div>
                  <h3 className={`text-lg font-bold ${
                    hasUnsavedNegativeAccounts ? 'text-red-700' : 'text-gray-900'
                  }`}>Negative Accounts</h3>
                  <p className={`text-sm flex items-center gap-1 font-normal ${
                    hasUnsavedNegativeAccounts && !showNegativeAccounts ? 'text-red-700' : 'text-red-600'
                  }`}>
                    <AlertTriangle className="w-4 h-4" />
                    {negativeAccounts.length} negative accounts need dispute review
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <span className={`text-sm ${
                  hasUnsavedNegativeAccounts ? 'text-red-700' : 'text-gray-600'
                }`}>
                  {negativeAccounts.length} accounts
                </span>
                {showNegativeAccounts ? (
                  <ChevronUp className={`w-4 h-4 ${
                    hasUnsavedNegativeAccounts ? 'text-red-700' : 'text-gray-600'
                  }`} />
                ) : (
                  <ChevronDown className={`w-4 h-4 ${
                    hasUnsavedNegativeAccounts ? 'text-red-700' : 'text-gray-600'
                  }`} />
                )}
              </div>
            </div>
          </CardHeader>
          
          {/* Show All Details Button - right-aligned below header */}
          {showNegativeAccounts && (
            <div className="px-6 pt-2 pb-0 flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAllDetails(!showAllDetails)}
                aria-label="Expand all negative account details"
                className="h-8 border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900"
              >
                {showAllDetails ? 'Hide All Details' : 'Show All Details'}
              </Button>
            </div>
          )}
          
          {showNegativeAccounts && (
            <CardContent className="px-6 pt-12 pb-6">
              <div className="flex flex-col space-y-3">
                {negativeAccounts.map((account: any, index: number) => {
                  const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
                  return (
                    <div key={`negative-wrapper-${accountId || index}`}>
                      <AccountRow
                        key={`negative-${accountId || index}`}
                        account={account}
                        aiViolations={aiViolations[account['@CreditLiabilityID']] || []}
                        disputeReasons={disputeReasons}
                        disputeInstructions={disputeInstructions}
                        onDisputeSaved={onDisputeSaved}
                        onDisputeReset={onDisputeReset}
                        expandAll={expandAll}
                        showAllDetails={showAllDetails}
                        aiScanCompleted={aiScanCompleted}
                        savedDisputes={savedDisputes}
                        isFirstInConnectedSection={index === 0}
                        allNegativeAccountsSaved={negativeAccounts.every(
                          (acc: any) =>
                            savedDisputes[
                              acc['@CreditLiabilityID'] ||
                                acc['@_AccountNumber'] ||
                                acc['@_AccountIdentifier']
                            ]
                        )}
                        isExpanded={undefined}
                      />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}