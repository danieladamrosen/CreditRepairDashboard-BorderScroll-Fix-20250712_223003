#!/usr/bin/env node

/**
 * Full Credit Report Data Integrity Check (JSON vs UI)
 * Examines raw JSON data structure and identifies any missing or filtered data
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load the credit data
const creditData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'donald-blair-credit-report.json'), 'utf8'));

console.log('🔍 FULL CREDIT REPORT DATA INTEGRITY AUDIT');
console.log('=' .repeat(60));

// Extract main data sections
const creditResponse = creditData.CREDIT_RESPONSE;
const borrower = creditResponse.BORROWER || {};
const addresses = creditResponse.BORROWER_ADDRESS || [];
const employers = creditResponse.BORROWER_EMPLOYMENT || [];
const accounts = creditResponse.CREDIT_LIABILITY || [];
const inquiries = creditResponse.CREDIT_INQUIRY || [];
const publicRecords = creditResponse.CREDIT_PUBLIC_RECORD || [];

console.log('\n📋 === PERSONAL INFO (BORROWER) ===');
console.log(JSON.stringify(borrower, null, 2));

console.log('\n🏠 === ADDRESSES (BORROWER_ADDRESS) ===');
console.log(JSON.stringify(addresses, null, 2));

console.log('\n💼 === EMPLOYERS (BORROWER_EMPLOYMENT) ===');
console.log(JSON.stringify(employers, null, 2));

console.log('\n📂 === ACCOUNTS (CREDIT_LIABILITY) ===');
console.log(`Total accounts found: ${accounts.length}`);
console.log('Sample account structure:');
if (accounts.length > 0) {
  console.log(JSON.stringify(accounts[0], null, 2));
}

console.log('\n🔍 === INQUIRIES (CREDIT_INQUIRY) ===');
console.log(`Total inquiries found: ${inquiries.length}`);
console.log('Sample inquiry structure:');
if (inquiries.length > 0) {
  console.log(JSON.stringify(inquiries[0], null, 2));
}

console.log('\n🧾 === PUBLIC RECORDS (CREDIT_PUBLIC_RECORD) ===');
console.log(`Total public records found: ${publicRecords.length}`);
if (publicRecords.length > 0) {
  console.log(JSON.stringify(publicRecords, null, 2));
}

// Calculate totals and statistics
console.log('\n📊 === DATA TOTALS & STATISTICS ===');
console.log('-'.repeat(40));

// Account statistics
const openAccounts = accounts.filter(acc => 
  acc['@_AccountStatusType']?.toLowerCase() === 'open'
).length;

const closedAccounts = accounts.filter(acc => 
  acc['@_AccountStatusType']?.toLowerCase() === 'closed'
).length;

const negativeAccounts = accounts.filter(acc => {
  return acc['@_DerogatoryDataIndicator'] === 'Y' ||
         acc['@IsCollectionIndicator'] === 'true' ||
         acc['@IsChargeoffIndicator'] === 'true' ||
         parseFloat(acc['@_PastDueAmount'] || '0') > 0;
}).length;

// Inquiry statistics
const cutoffDate = new Date();
cutoffDate.setMonth(cutoffDate.getMonth() - 24);

const recentInquiries = inquiries.filter(inq => {
  const inquiryDate = new Date(inq['@_InquiryDate']);
  return inquiryDate > cutoffDate;
}).length;

const olderInquiries = inquiries.filter(inq => {
  const inquiryDate = new Date(inq['@_InquiryDate']);
  return inquiryDate <= cutoffDate;
}).length;

// Calculate total balance
const totalBalance = accounts.reduce((sum, acc) => {
  const balance = acc['@_UnpaidBalanceAmount'] || 
                 acc['@_HighBalanceAmount'] || 
                 acc['@_CreditLimitAmount'] || 0;
  return sum + parseFloat(balance.toString());
}, 0);

console.log(`✅ Raw Data: ${accounts.length} accounts total (${openAccounts} open, ${closedAccounts} closed, ${negativeAccounts} negative)`);
console.log(`✅ Raw Data: ${inquiries.length} inquiries total (${recentInquiries} recent, ${olderInquiries} older)`);
console.log(`✅ Raw Data: ${addresses.length} addresses found`);
console.log(`✅ Raw Data: ${employers.length} employers found`);
console.log(`✅ Raw Data: ${publicRecords.length} public records found`);
console.log(`✅ Raw Data: $${totalBalance.toLocaleString()} total balance`);

// Check for potential data issues
console.log('\n⚠️  === POTENTIAL DATA ISSUES ===');
console.log('-'.repeat(40));

// Check if addresses are missing
if (addresses.length === 0) {
  console.log('❌ ISSUE: No addresses found in BORROWER_ADDRESS');
  console.log('   → Check if personal-info.tsx is looking in the wrong location');
  console.log('   → Raw borrower object might contain address fields directly');
}

// Check if employers are missing
if (employers.length === 0) {
  console.log('❌ ISSUE: No employers found in BORROWER_EMPLOYMENT');
  console.log('   → Check if personal-info.tsx is looking in the wrong location');
  console.log('   → Employment data might be stored differently');
}

// Check borrower structure
console.log('\n📋 === BORROWER FIELD ANALYSIS ===');
if (borrower && typeof borrower === 'object') {
  const borrowerFields = Object.keys(borrower);
  console.log(`Borrower has ${borrowerFields.length} fields:`);
  borrowerFields.forEach(field => {
    console.log(`  - ${field}: ${borrower[field]}`);
  });
} else {
  console.log('❌ ISSUE: Borrower data structure is invalid or missing');
}

// Check account field consistency
console.log('\n📂 === ACCOUNT FIELD ANALYSIS ===');
if (accounts.length > 0) {
  const sampleAccount = accounts[0];
  const accountFields = Object.keys(sampleAccount);
  console.log(`Each account has ${accountFields.length} fields`);
  
  // Check for key account fields
  const keyFields = [
    '@CreditLiabilityID',
    '@_AccountStatusType', 
    '@_UnpaidBalanceAmount',
    '@_SubscriberName',
    '@_CreditorName',
    '@_DerogatoryDataIndicator'
  ];
  
  keyFields.forEach(field => {
    const hasField = accountFields.includes(field);
    console.log(`  ${hasField ? '✅' : '❌'} ${field}: ${hasField ? 'Present' : 'Missing'}`);
  });
}

// Check inquiry field consistency
console.log('\n🔍 === INQUIRY FIELD ANALYSIS ===');
if (inquiries.length > 0) {
  const sampleInquiry = inquiries[0];
  const inquiryFields = Object.keys(sampleInquiry);
  console.log(`Each inquiry has ${inquiryFields.length} fields`);
  
  // Check for key inquiry fields
  const keyInquiryFields = [
    '@CreditInquiryID',
    '@_InquiryDate',
    '@_SubscriberName',
    '@CreditRepositorySourceType'
  ];
  
  keyInquiryFields.forEach(field => {
    const hasField = inquiryFields.includes(field);
    console.log(`  ${hasField ? '✅' : '❌'} ${field}: ${hasField ? 'Present' : 'Missing'}`);
  });
}

console.log('\n🎯 === SUMMARY & RECOMMENDATIONS ===');
console.log('-'.repeat(40));

if (addresses.length === 0) {
  console.log('🔧 FIX NEEDED: Address data missing');
  console.log('   → Check client/src/components/credit-report/personal-info.tsx');
  console.log('   → Look for BORROWER_ADDRESS parsing logic');
}

if (employers.length === 0) {
  console.log('🔧 FIX NEEDED: Employer data missing');
  console.log('   → Check client/src/components/credit-report/personal-info.tsx');
  console.log('   → Look for BORROWER_EMPLOYMENT parsing logic');
}

if (accounts.length !== (openAccounts + closedAccounts)) {
  console.log('🔧 FIX NEEDED: Account status categorization may be incomplete');
  console.log(`   → ${accounts.length} total accounts vs ${openAccounts + closedAccounts} categorized accounts`);
}

console.log('\n✅ Audit Complete - Check output above for specific issues to fix');