// Simple test to verify the final choreography
console.log("Testing final choreography behavior...");

// Find the first negative account that isn't saved yet
const cards = document.querySelectorAll('.space-y-6 > div, [class*="bg-red"], [class*="bg-pink"]');
let testCard = null;

for (const card of cards) {
  const saveBtn = card.querySelector('button[type="submit"]');
  if (saveBtn && !saveBtn.textContent.includes('Dispute Saved')) {
    testCard = card;
    console.log("Found unsaved account to test");
    break;
  }
}

if (testCard) {
  // Fill required fields
  const selects = testCard.querySelectorAll('select');
  if (selects.length >= 2) {
    selects[0].value = selects[0].options[1].value;
    selects[1].value = selects[1].options[1].value;
    selects[0].dispatchEvent(new Event('change', { bubbles: true }));
    selects[1].dispatchEvent(new Event('change', { bubbles: true }));
    console.log("Filled form fields");
  }
  
  // Save and monitor results
  setTimeout(() => {
    console.log("Saving account...");
    testCard.querySelector('button[type="submit"]').click();
    
    // Check results every second for 5 seconds
    for (let i = 1; i <= 5; i++) {
      setTimeout(() => {
        console.log(`Check ${i}:`);
        
        const summary = document.querySelector('.bg-green-50.cursor-pointer');
        console.log(`- Green summary box: ${summary ? 'FOUND' : 'MISSING'}`);
        
        const accounts = document.querySelectorAll('[data-account-type="negative"]');
        console.log(`- Individual accounts: ${accounts.length}`);
        
        const heading = Array.from(document.querySelectorAll('h3')).find(h => h.textContent.includes('Credit Accounts'));
        if (heading) {
          const pos = heading.getBoundingClientRect().top;
          console.log(`- Heading position: ${Math.round(pos)}px`);
        }
        
        if (i === 4 && summary) {
          console.log("Testing green box click...");
          summary.click();
        }
      }, i * 1000);
    }
  }, 500);
} else {
  console.log("No unsaved accounts found");
}
