import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronUp, AlertTriangle } from 'lucide-react';
import { AccountRow } from './account-row';

interface ExpandedNegativeAccountsProps {
  handleToggle: () => void;
  negativeAccounts: any[];
  negativeAccountsCollapsed: boolean;
  creditData: any;
  aiViolations: { [accountId: string]: string[] };
  disputeReasons: any;
  disputeInstructions: any;
  onDisputeSaved: (accountId: string, disputeData: any) => void;
  onDisputeReset: (accountId: string) => void;
  aiScanCompleted: boolean;
  savedDisputes: { [accountId: string]: boolean | { reason: string; instruction: string; violations?: string[] } };
  showNegativeAccounts: boolean;
  setShowNegativeAccounts: (show: boolean) => void;
  expandAll: boolean;
  setExpandAll: (expand: boolean) => void;
  showAllDetails: boolean;
  setShowAllDetails: (show: boolean) => void;
}

export default function ExpandedNegativeAccounts({
  handleToggle,
  negativeAccounts,
  negativeAccountsCollapsed,
  creditData,
  aiViolations,
  disputeReasons,
  disputeInstructions,
  onDisputeSaved,
  onDisputeReset,
  aiScanCompleted,
  savedDisputes,
  showNegativeAccounts,
  setShowNegativeAccounts,
  expandAll,
  setExpandAll,
  showAllDetails,
  setShowAllDetails,
}: ExpandedNegativeAccountsProps) {
  return (
    <Card key="negative-expanded" className="border-2 border-gray-300 bg-white rounded-lg shadow-sm">
      <CardHeader
        onClick={handleToggle}
        className="flex flex-row items-center justify-between cursor-pointer hover:bg-gray-50"
      >
        <div className="flex flex-row items-center gap-2">
          <div className="bg-red-500 text-white text-xs font-bold rounded-full w-8 h-8 flex items-center justify-center">
            {negativeAccounts.length}
          </div>
          <div>
            <h3 className="text-lg font-bold text-red-700">
              Negative Accounts
            </h3>
            <p className="flex flex-row items-center gap-2 text-sm text-red-600">
              <AlertTriangle className="h-4 w-4" />
              {negativeAccounts.length} negative accounts need dispute review
            </p>
          </div>
        </div>
        <div className="flex flex-row items-center gap-2 text-sm font-bold text-red-600">
          {negativeAccounts.length} accounts
          <ChevronUp className="h-4 w-4 text-gray-600" />
        </div>
      </CardHeader>

      <CardContent className="p-4">
        {/* Show All Details Button - right-aligned below header */}
        {showNegativeAccounts && (
          <div className="pb-4 flex justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAllDetails(!showAllDetails)}
              aria-label="Expand all negative account details"
              className="h-8 border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900"
            >
              {showAllDetails ? 'Hide All Details' : 'Show All Details'}
            </Button>
          </div>
        )}
        
        {/* Account rows */}
        {showNegativeAccounts && (
          <div className="flex flex-col space-y-3">
            {negativeAccounts.map((account: any, index: number) => {
              const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
              return (
                <div key={`negative-wrapper-${accountId || index}`}>
                  <AccountRow
                    key={`negative-${accountId || index}`}
                    account={account}
                    aiViolations={aiViolations[account['@CreditLiabilityID']] || []}
                    disputeReasons={disputeReasons}
                    disputeInstructions={disputeInstructions}
                    onDisputeSaved={onDisputeSaved}
                    onDisputeReset={onDisputeReset}
                    expandAll={expandAll}
                    showAllDetails={showAllDetails}
                    aiScanCompleted={aiScanCompleted}
                    savedDisputes={savedDisputes}
                    isFirstInConnectedSection={index === 0}
                    allNegativeAccountsSaved={negativeAccounts.every(
                      (acc: any) =>
                        savedDisputes[
                          acc['@CreditLiabilityID'] ||
                            acc['@_AccountNumber'] ||
                            acc['@_AccountIdentifier']
                        ]
                    )}
                    isExpanded={undefined}
                  />
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}