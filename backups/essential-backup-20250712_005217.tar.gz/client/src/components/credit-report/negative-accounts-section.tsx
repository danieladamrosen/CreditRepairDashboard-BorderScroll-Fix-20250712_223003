import { useRef, useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronUp, ChevronDown, AlertTriangle } from 'lucide-react';
import { AccountRow } from './account-row';
import { SavedCollapsedCard } from '@/components/ui/saved-collapsed-card';
import { cn } from '@/lib/utils';

interface NegativeAccountsSectionProps {
  creditData: any;
  aiViolations: { [accountId: string]: string[] };
  disputeReasons: any;
  disputeInstructions: any;
  onDisputeSaved: (accountId: string, disputeData: any) => void;
  onDisputeReset: (accountId: string) => void;
  aiScanCompleted: boolean;
  savedDisputes: { [accountId: string]: boolean | { reason: string; instruction: string; violations?: string[] } };
  showNegativeAccounts: boolean;
  setShowNegativeAccounts: (show: boolean) => void;
  expandAll: boolean;
  setExpandAll: (expand: boolean) => void;
  showAllDetails: boolean;
  setShowAllDetails: (show: boolean) => void;
  negativeAccountsCollapsed: boolean;
  setNegativeAccountsCollapsed: (collapsed: boolean) => void;
  showCreditAccounts: boolean;
  userHasManuallyExpanded: boolean;
  setUserHasManuallyExpanded: (expanded: boolean) => void;
  showRedOnNegativeAccounts?: boolean;
}

export default function NegativeAccountsSection({
  creditData,
  aiViolations,
  disputeReasons,
  disputeInstructions,
  onDisputeSaved,
  onDisputeReset,
  aiScanCompleted,
  savedDisputes,
  showNegativeAccounts,
  setShowNegativeAccounts,
  expandAll,
  setExpandAll,
  showAllDetails,
  setShowAllDetails,
  negativeAccountsCollapsed,
  setNegativeAccountsCollapsed,
  showCreditAccounts,
  userHasManuallyExpanded,
  setUserHasManuallyExpanded,
  showRedOnNegativeAccounts = false,
}: NegativeAccountsSectionProps) {
  const negativeAccountsRef = useRef<HTMLDivElement>(null);
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({});

  // Function to determine if an account is negative
  const isNegativeAccount = (account: any) => {
    // 1. Check derogatory data indicator
    if (account['@_DerogatoryDataIndicator'] === 'Y') {
      return true;
    }

    // 2. Check for collection accounts
    if (account['@IsCollectionIndicator'] === 'true' || account['@IsCollectionIndicator'] === 'Y') {
      return true;
    }

    // 3. Check for charge-off accounts
    if (account['@IsChargeoffIndicator'] === 'true' || account['@IsChargeoffIndicator'] === 'Y') {
      return true;
    }

    // 4. Check for past due amounts (indicates late payments)
    if (account['@_PastDueAmount'] && parseFloat(account['@_PastDueAmount']) > 0) {
      return true;
    }

    // 5. Check current rating for negative codes
    const currentRating = account['_CURRENT_RATING'];
    if (currentRating && currentRating['@_Code']) {
      const code = currentRating['@_Code'];
      // Negative rating codes: 2-9 (late payments), collections, charge-offs
      if (['2', '3', '4', '5', '6', '7', '8', '9', 'G', 'H', 'J', 'K', 'L'].includes(code)) {
        return true;
      }
    }

    // 6. Check for charge-off date
    if (account['@_ChargeOffDate']) {
      return true;
    }

    return false;
  };

  // Get negative accounts data
  const accounts = creditData?.CREDIT_RESPONSE?.CREDIT_LIABILITY || [];
  const negativeAccounts = accounts.filter((account: any) => isNegativeAccount(account));

  // Compute summary text for saved disputes
  const totalSavedDisputes = negativeAccounts.filter((account: any) => {
    const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
    return savedDisputes[accountId];
  }).length;
  const summaryText = `You've saved disputes for ${totalSavedDisputes} negative account(s) across TransUnion, Equifax, and Experian.`;

  // Check if all negative accounts have saved disputes
  const allNegativeAccountsSaved = negativeAccounts.length > 0 && negativeAccounts.every((account: any) => {
    const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
    return savedDisputes[accountId];
  });

  // Handle toggle for both states
  const handleToggle = () => {
    if (negativeAccountsCollapsed) {
      setNegativeAccountsCollapsed(false);
      setShowNegativeAccounts(true);
      setUserHasManuallyExpanded(true);
    } else {
      setShowNegativeAccounts(!showNegativeAccounts);
    }
  };

  return (
    <div ref={negativeAccountsRef}>
      {allNegativeAccountsSaved ? (
        <SavedCollapsedCard
          sectionName="Negative Accounts"
          successMessage="Negative Accounts – Disputes Saved"
          summaryText={summaryText}
          onExpand={() => {
            setNegativeAccountsCollapsed(false);
            setShowNegativeAccounts(true);
            setUserHasManuallyExpanded(true);
          }}
        />
      ) : (
        <Card
          className={cn(
            "rounded-lg overflow-hidden",
            negativeAccountsCollapsed
              ? "border-2 border-red-500 bg-red-50 hover:bg-red-100 hover:shadow-lg"
              : "border-2 border-gray-300 bg-white shadow-sm"
          )}
        >
          <CardHeader
            onClick={handleToggle}
            className={cn(
              "flex flex-row items-center justify-between cursor-pointer",
              negativeAccountsCollapsed ? "" : "hover:bg-gray-50"
            )}
          >
            <div className="flex flex-row items-center gap-2">
              <Badge className="bg-red-500 text-white text-xs font-bold rounded-full">
                {negativeAccounts.length}
              </Badge>
              <div>
                <h3
                  className={cn(
                    "text-lg font-bold",
                    negativeAccountsCollapsed ? "text-red-700" : "text-gray-900"
                  )}
                >
                  Negative Accounts
                </h3>
                <p
                  className={cn(
                    "flex flex-row items-center gap-2 text-sm",
                    negativeAccountsCollapsed ? "text-red-600" : "text-gray-600"
                  )}
                >
                  <AlertTriangle className="h-4 w-4" />
                  {negativeAccounts.length} negative accounts need dispute review
                </p>
              </div>
            </div>
            <div
              className={cn(
                "flex flex-row items-center gap-2 text-sm font-bold",
                negativeAccountsCollapsed ? "text-red-600" : "text-gray-600"
              )}
            >
              {negativeAccounts.length} accounts
              {negativeAccountsCollapsed ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronUp className="h-4 w-4" />
              )}
            </div>
          </CardHeader>

          {!negativeAccountsCollapsed && (
            <CardContent className="p-4">
              {/* Show All Details Button - right-aligned below header */}
              {showNegativeAccounts && (
                <div className="pb-4 flex justify-end">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAllDetails(!showAllDetails)}
                    aria-label="Expand all negative account details"
                    className="h-8 border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                  >
                    {showAllDetails ? 'Hide All Details' : 'Show All Details'}
                  </Button>
                </div>
              )}
              
              {/* Account rows */}
              {showNegativeAccounts && (
                <div className="flex flex-col space-y-3">
                  {negativeAccounts.map((account: any, index: number) => {
                    const accountId = account['@CreditLiabilityID'] || account['@_AccountNumber'] || account['@_AccountIdentifier'];
                    return (
                      <div key={`negative-wrapper-${accountId || index}`}>
                        <AccountRow
                          key={`negative-${accountId || index}`}
                          account={account}
                          aiViolations={aiViolations[account['@CreditLiabilityID']] || []}
                          disputeReasons={disputeReasons}
                          disputeInstructions={disputeInstructions}
                          onDisputeSaved={onDisputeSaved}
                          onDisputeReset={onDisputeReset}
                          expandAll={expandAll}
                          showAllDetails={showAllDetails}
                          aiScanCompleted={aiScanCompleted}
                          savedDisputes={savedDisputes}
                          isFirstInConnectedSection={index === 0}
                          allNegativeAccountsSaved={negativeAccounts.every(
                            (acc: any) =>
                              savedDisputes[
                                acc['@CreditLiabilityID'] ||
                                  acc['@_AccountNumber'] ||
                                  acc['@_AccountIdentifier']
                              ]
                          )}
                          isExpanded={undefined}
                        />
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}