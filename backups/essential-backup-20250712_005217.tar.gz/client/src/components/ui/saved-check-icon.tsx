import { CheckIcon } from 'lucide-react';

interface SavedCheckIconProps {
  className?: string;
}

export function SavedCheckIcon({ className = "" }: SavedCheckIconProps) {
  return (
    <div className={`flex items-center justify-center w-8 h-8 rounded-full bg-green-600 ${className}`}>
      <CheckIcon className="w-4 h-4 text-white" />
    </div>
  );
}