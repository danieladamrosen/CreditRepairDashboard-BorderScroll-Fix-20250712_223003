// AI Guide Integration for FCRA/FDCPA Reference
export const FCRA_VIOLATIONS_GUIDE = {
  violations: [
    {
      id: 1,
      title: "Inaccurate Reporting of Paid/Settled Debts",
      description: "Debt reported as outstanding despite being paid in full",
      disputeLanguage: "My credit report shows an outstanding balance owed to [Furnisher]. This account was paid in full, and no further amount is due.",
      keywords: ["paid", "settled", "outstanding balance", "paid in full"]
    },
    {
      id: 2,
      title: "Reporting of Accounts Discharged in Bankruptcy",
      description: "Debt shows a balance despite being discharged",
      disputeLanguage: "This account was discharged in a bankruptcy. I am requesting that this account be updated to reflect a zero balance.",
      keywords: ["bankruptcy", "discharged", "balance", "zero balance"]
    },
    {
      id: 3,
      title: "Mixed Credit Information",
      description: "Credit information of another person appears on report",
      disputeLanguage: "My credit report shows many accounts and information that does not belong to me. I believe that my credit file has been mixed with someone else's file.",
      keywords: ["mixed file", "not mine", "wrong person", "incorrect information"]
    },
    {
      id: 4,
      title: "Incorrect Late Payments",
      description: "Payments marked late when they were made on time",
      disputeLanguage: "My credit report is showing late payments to [Furnisher]. Those payments were made on time. I am requesting that the late payment markings be updated.",
      keywords: ["late payment", "on time", "payment history", "incorrect timing"]
    },
    {
      id: 5,
      title: "Duplicate Accounts",
      description: "The same account is listed multiple times",
      disputeLanguage: "My credit report shows a debt owed to [Furnisher] twice. I am requesting that one of the duplicate accounts be removed.",
      keywords: ["duplicate", "same account", "multiple times", "listed twice"]
    },
    {
      id: 6,
      title: "Short Sale Listed as Foreclosure",
      description: "After a short sale, the mortgage account should report as a short sale and not as a foreclosure",
      disputeLanguage: "My credit report incorrectly lists a short sale as a foreclosure. I am requesting that this error be corrected.",
      keywords: ["short sale", "foreclosure", "mortgage", "incorrect status"]
    },
    {
      id: 7,
      title: "Fraudulent/Unknown Account",
      description: "Unknown account appears on report",
      disputeLanguage: "My credit report shows accounts that does not belong to me. I am requesting that this account be removed.",
      keywords: ["fraudulent", "unknown", "not mine", "identity theft"]
    },
    {
      id: 8,
      title: "Authorized User Report Shows All Activity",
      description: "Users activity showing on authorized user's credit report",
      disputeLanguage: "My credit report shows all user activities for an account where I am an authorized user. I am requesting that only my activities be reported.",
      keywords: ["authorized user", "all activity", "primary user", "joint account"]
    },
    {
      id: 9,
      title: "Outdated Account",
      description: "7 years old negative account is still reporting",
      disputeLanguage: "My credit report shows negative account older than 7 years. I am requesting that these outdated accounts be removed.",
      keywords: ["7 years", "outdated", "old", "expired", "statute of limitations"]
    },
    {
      id: 10,
      title: "Debt Buyer and Original Creditor Reporting Balance",
      description: "Debt buyer and original creditor are both reporting balance",
      disputeLanguage: "My credit report shows both the debt buyer and original creditor reporting the same balance. I am requesting that one of these duplicate balances be removed.",
      keywords: ["debt buyer", "original creditor", "double reporting", "same balance"]
    }
  ]
};

export const METRO_2_VIOLATIONS_GUIDE = {
  reportingRequirements: {
    monthlyReporting: "Accounts must be reported monthly with accurate, complete and timely information",
    dataConsistency: "More consistent data reporting across all consumer reporting agencies",
    automatedUpdates: "Automated updates and corrections required for compliance"
  },
  commonViolations: [
    {
      id: 1,
      title: "Incorrect Terms Duration Reporting",
      description: "Terms Duration field not properly formatted - should be right justified and zero filled",
      disputeLanguage: "The Terms Duration field is incorrectly reported. Per Metro 2 standards, this field should be right-justified and zero-filled.",
      technicalRequirement: "Alphanumeric field must be left-justified and blank filled"
    },
    {
      id: 2,
      title: "Missing Date of First Delinquency",
      description: "System fails to report accurate date of first delinquency",
      disputeLanguage: "The Date of First Delinquency is missing or inaccurate. This violates Metro 2 reporting requirements.",
      technicalRequirement: "Must report date of first delinquency, zeros if account becomes current"
    },
    {
      id: 3,
      title: "Incorrect Payment History Profile",
      description: "24-month payment history not properly updated based on status code",
      disputeLanguage: "The Payment History Profile contains inaccuracies that violate Metro 2 compliance standards.",
      technicalRequirement: "System must update payment history based on current status code"
    },
    {
      id: 4,
      title: "Invalid Account Status Code",
      description: "Account status code inconsistent with actual account status",
      disputeLanguage: "The Account Status Code is inconsistent with the actual account status, violating Metro 2 format requirements.",
      technicalRequirement: "Status code must accurately reflect current account condition"
    },
    {
      id: 5,
      title: "Missing Compliance Condition Code",
      description: "Required compliance condition code missing from report",
      disputeLanguage: "The required Compliance Condition Code is missing from this account, which violates Metro 2 reporting standards.",
      technicalRequirement: "Compliance condition code must be manually maintained and present"
    }
  ],
  portfolioTypes: {
    installment: { code: "I", description: "Loan repayable in installments" },
    lineOfCredit: { code: "C", description: "Credit line with revolving payments" },
    mortgage: { code: "M", description: "Real estate conveyance instrument" },
    openAccount: { code: "O", description: "Credit extended on general ability to pay" },
    revolving: { code: "R", description: "Maximum credit limit with revolving payments" }
  }
};

export const FDCPA_VIOLATIONS_GUIDE = {
  categories: {
    harassment: {
      title: "Harassment or Abuse",
      violations: [
        "The use of threats of violence or harm",
        "Publishing a list of consumers who refuse to pay debts",
        "The use of obscene or profane language",
        "Repeatedly calling the consumer to annoy or harass"
      ]
    },
    misrepresentation: {
      title: "False or Misleading Representations",
      violations: [
        "Misrepresenting the amount owed",
        "Falsely claiming to be an attorney or government representative",
        "Falsely claiming that the consumer has committed a crime",
        "Threatening to take legal action that is not intended or cannot be taken"
      ]
    },
    unfairPractices: {
      title: "Unfair Practices",
      violations: [
        "Collecting any amount greater than what is owed unless permitted by law",
        "Depositing a post-dated check prematurely",
        "Taking or threatening to take property that cannot legally be taken",
        "Communicating with a consumer by postcard"
      ]
    }
  }
};

export function detectMetro2Violations(accountData: any): Array<{violation: any, confidence: number, evidence: string[]}> {
  const detectedViolations = [];
  
  for (const violation of METRO_2_VIOLATIONS_GUIDE.commonViolations) {
    const evidence = [];
    let confidence = 0;
    
    switch (violation.id) {
      case 1: // Terms Duration formatting
        if (accountData['@_TermsDescription'] && 
            !accountData['@_TermsDescription'].match(/^\d{3}$/)) {
          evidence.push('Terms Duration not properly formatted (should be 3 digits, zero-filled)');
          confidence += 0.7;
        }
        break;
        
      case 2: // Missing Date of First Delinquency
        if ((accountData['@_AccountStatusType']?.includes('Late') || 
             accountData['@_AccountStatusType']?.includes('Collection')) &&
            !accountData['@_DateFirstDelinquency']) {
          evidence.push('Account shows delinquency but missing Date of First Delinquency');
          confidence += 0.8;
        }
        break;
        
      case 3: // Payment History issues
        if (accountData.PAYMENT_PATTERN?.['@_Data'] && 
            accountData.PAYMENT_PATTERN['@_Data'].includes('B') && 
            accountData.PAYMENT_PATTERN['@_Data'].length < 24) {
          evidence.push('Payment history incomplete or improperly formatted');
          confidence += 0.6;
        }
        break;
        
      case 4: // Account Status inconsistency
        const currentBalance = parseFloat(accountData['@_CurrentBalance'] || '0');
        const accountStatus = accountData['@_AccountStatusType'];
        if (currentBalance === 0 && accountStatus?.includes('Open')) {
          evidence.push('Zero balance account still reported as open');
          confidence += 0.5;
        }
        break;
        
      case 5: // Missing compliance codes
        if (!accountData['@_ComplianceConditionCode'] && 
            (accountData['@_AccountStatusType']?.includes('Collection') ||
             accountData['@_AccountStatusType']?.includes('Charge'))) {
          evidence.push('Negative account missing required compliance condition code');
          confidence += 0.6;
        }
        break;
    }
    
    if (confidence > 0.4) {
      detectedViolations.push({
        violation,
        confidence: Math.min(confidence, 1.0),
        evidence
      });
    }
  }
  
  return detectedViolations.sort((a, b) => b.confidence - a.confidence);
}

export function detectFCRAViolations(accountData: any): Array<{violation: any, confidence: number, evidence: string[]}> {
  const detectedViolations = [];
  
  for (const violation of FCRA_VIOLATIONS_GUIDE.violations) {
    const evidence = [];
    let confidence = 0;
    
    // Check for keyword matches in account data
    const accountText = JSON.stringify(accountData).toLowerCase();
    
    for (const keyword of violation.keywords) {
      if (accountText.includes(keyword.toLowerCase())) {
        evidence.push(`Found keyword: ${keyword}`);
        confidence += 0.2;
      }
    }
    
    // Specific violation detection logic
    switch (violation.id) {
      case 1: // Paid/Settled Debts
        if (accountData['@_AccountStatusType']?.includes('Paid') && 
            parseFloat(accountData['@_CurrentBalance'] || '0') > 0) {
          evidence.push('Account marked as paid but shows outstanding balance');
          confidence += 0.5;
        }
        break;
        
      case 4: // Incorrect Late Payments
        if (accountData.PAYMENT_PATTERN && 
            accountData.PAYMENT_PATTERN['@_Data']?.includes('3') || 
            accountData.PAYMENT_PATTERN['@_Data']?.includes('4')) {
          evidence.push('Late payment indicators found in payment pattern');
          confidence += 0.3;
        }
        break;
        
      case 9: // Outdated Accounts
        const currentDate = new Date();
        const accountDate = new Date(accountData['@_DateOpened'] || accountData['@_DateClosed']);
        const yearsDiff = (currentDate.getTime() - accountDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
        
        if (yearsDiff > 7 && (accountData['@_AccountStatusType']?.includes('Collection') || 
                              accountData['@_AccountStatusType']?.includes('Charge'))) {
          evidence.push(`Account is ${Math.floor(yearsDiff)} years old and still reporting negatively`);
          confidence += 0.8;
        }
        break;
    }
    
    if (confidence > 0.3) {
      detectedViolations.push({
        violation,
        confidence: Math.min(confidence, 1.0),
        evidence
      });
    }
  }
  
  return detectedViolations.sort((a, b) => b.confidence - a.confidence);
}

export function generateEnhancedDisputeLanguage(violation: any, accountData: any): string {
  let disputeText = violation.disputeLanguage;
  
  // Replace placeholders with actual account data
  if (accountData._CREDITOR?.['@_Name']) {
    disputeText = disputeText.replace('[Furnisher]', accountData._CREDITOR['@_Name']);
  }
  
  // Add specific legal citations based on violation type
  switch (violation.id) {
    case 2: // Bankruptcy discharge
      disputeText += " Per FCRA Section 605(a)(1), discharged debts should reflect zero balance.";
      break;
    case 9: // Outdated accounts
      disputeText += " Per FCRA Section 605(a)(4), negative information older than 7 years must be removed.";
      break;
    case 10: // Double reporting
      disputeText += " This constitutes double jeopardy under FCRA Section 623 and must be corrected.";
      break;
  }
  
  return disputeText;
}