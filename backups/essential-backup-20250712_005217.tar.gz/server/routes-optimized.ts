import { Express, Request, Response } from "express";
import OpenAI from 'openai';

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Token counting helper
function countTokens(text: string): number {
  try {
    // Simple approximation: ~4 characters per token
    return Math.ceil(text.length / 4);
  } catch (error) {
    return Math.ceil(text.length / 4);
  }
}

// Static violation generators
function getStaticViolationsForAccount(account: any, index: number): string[] {
  const violations = [
    "Metro 2 Violation: Account reporting inconsistent balance amounts",
    "FCRA Violation: Failure to conduct reasonable investigation of dispute",
    "FDCPA Violation: Improper debt collection practices reported"
  ];
  return violations;
}

function getStaticPublicRecordViolations(index: number): string[] {
  return [
    "Metro 2 Violation: Public record information is outdated or inaccurate",
    "FCRA Violation: Public record lacks proper verification",
    "FDCPA Violation: Public record collection activity violates guidelines"
  ];
}

function getStaticViolationsForItem(item: any, itemType: string, index: number): string[] {
  if (itemType === 'public_record') {
    return getStaticPublicRecordViolations(index);
  } else if (itemType === 'inquiry') {
    return [
      "Metro 2 Violation: Inquiry exceeds permissible purpose timeframe",
      "FCRA Violation: Inquiry lacks proper authorization documentation",
      "FDCPA Violation: Inquiry related to unauthorized debt collection"
    ];
  }
  return getStaticViolationsForAccount(item, index);
}

// OPTIMIZED: Main AI scan function with parallel processing
async function performAiScan(creditData: any, sendProgress: (progress: number, message: string) => void) {
  console.log("🔍 Starting OPTIMIZED AI scan with parallel processing");
  
  // OPTIMIZED: Configuration for GPT-3.5-turbo-1106
  const ENCODING_MODEL = 'gpt-3.5-turbo-1106';
  const MAX_INPUT_TOKENS = 100000;
  const TOKENS_PER_ACCOUNT_LIMIT = 1000;
  const MAX_TOKENS_RESPONSE = 1000; // Reduced from 1500
  const MAX_CONCURRENT_REQUESTS = 5; // Concurrency limit

  sendProgress(5, "Analyzing credit data structure...");
  
  // Calculate total input tokens
  const creditDataText = JSON.stringify(creditData);
  const totalInputTokens = countTokens(creditDataText);
  console.log(`📊 Total input tokens: ${totalInputTokens.toLocaleString()}`);
  
  if (totalInputTokens > MAX_INPUT_TOKENS) {
    console.log(`🚫 INPUT TOO LARGE: ${totalInputTokens.toLocaleString()} tokens exceeds limit`);
    throw new Error(`INPUT_TOO_LARGE: ${totalInputTokens.toLocaleString()} tokens exceeds limit`);
  }
  
  sendProgress(10, "Validating API credentials...");
  
  const openaiApiKey = process.env.OPENAI_API_KEY;
  if (!openaiApiKey) {
    console.log("🚫 No OpenAI API key found, using static violations");
    return generateStaticViolations(creditData);
  }

  sendProgress(15, "Extracting credit report items...");

  // Extract items from credit data
  const negativeAccounts = creditData?.CREDIT_RESPONSE?.CREDIT_LIABILITY?.filter((account: any) => {
    const isDerogatoryIndicator = account["@_DerogatoryDataIndicator"] === "Y";
    const isCollection = account["@IsCollectionIndicator"] === "Y";
    const isChargeoff = account["@IsChargeoffIndicator"] === "Y";
    const hasPastDue = account["@_PastDueAmount"] && parseFloat(account["@_PastDueAmount"]) > 0;
    const hasNegativeRating = account._CURRENT_RATING && 
      ["2", "3", "4", "5", "6", "7", "8", "9"].includes(account._CURRENT_RATING["@_Code"]);
    const hasChargeOffDate = account["@_ChargeOffDate"];
    
    return isDerogatoryIndicator || isCollection || isChargeoff || hasPastDue || hasNegativeRating || hasChargeOffDate;
  }) || [];

  const publicRecords = creditData?.CREDIT_RESPONSE?.PUBLIC_RECORD || [];
  const recentInquiries = creditData?.CREDIT_RESPONSE?.INQUIRY?.filter((inquiry: any) => {
    const inquiryDate = new Date(inquiry["@_Date"]);
    const twoYearsAgo = new Date();
    twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
    return inquiryDate > twoYearsAgo;
  }) || [];

  console.log(`📊 Found ${negativeAccounts.length} negative accounts, ${publicRecords.length} public records, ${recentInquiries.length} recent inquiries`);

  const violations: { [key: string]: string[] } = {};
  let accountsAnalyzedWithAI = 0;
  let accountsSkippedByTokens = 0;
  let totalAccountsProcessed = 0;

  // OPTIMIZED: Create all items to process with parallel processing
  const allItemsToProcess: any[] = [
    ...negativeAccounts.map((item: any, index: number) => ({ ...item, itemType: 'account', originalIndex: index })),
    ...publicRecords.map((item: any, index: number) => ({ ...item, itemType: 'public_record', originalIndex: index })),
    ...recentInquiries.map((item: any, index: number) => ({ ...item, itemType: 'inquiry', originalIndex: index }))
  ];

  console.log(`🎯 Total items to process: ${allItemsToProcess.length}`);
  sendProgress(20, `Starting parallel analysis of ${allItemsToProcess.length} items...`);

  // OPTIMIZED: Helper function to process a single item with OpenAI
  const processItemWithAI = async (item: any, itemIndex: number): Promise<{ itemId: string, violations: string[] }> => {
    const itemType = item.itemType;
    
    // Generate item ID based on type
    let itemId: string;
    if (itemType === 'account') {
      itemId = item["@CreditLiabilityID"] || `TRADE${String(itemIndex + 1).padStart(3, '0')}`;
    } else if (itemType === 'public_record') {
      itemId = item["@_PublicRecordIdentifier"] || `PUBLIC-RECORD-${itemIndex + 1}`;
    } else if (itemType === 'inquiry') {
      itemId = item["@_InquiryIdentifier"] || `INQUIRY-${itemIndex + 1}`;
    } else {
      itemId = `ITEM-${itemIndex + 1}`;
    }
    
    try {
      // Create item summary based on type
      let itemSummary: any;
      if (itemType === 'account') {
        itemSummary = {
          creditor: item._CREDITOR?.['@_Name'] || 'Unknown',
          status: item['@_AccountStatusType'] || 'Unknown',
          balance: item['@_CurrentBalance'] || '0',
          accountType: item['@_AccountType'] || 'Unknown',
          rating: item['@_AccountCurrentRatingCode'] || 'Unknown'
        };
      } else if (itemType === 'public_record') {
        itemSummary = {
          type: item['@_Type'] || 'Unknown',
          status: item['@_Status'] || 'Unknown', 
          amount: item['@_Amount'] || '0',
          date: item['@_Date'] || 'Unknown',
          court: item['@_Court'] || 'Unknown'
        };
      } else if (itemType === 'inquiry') {
        itemSummary = {
          subscriberName: item['@_SubscriberName'] || 'Unknown',
          date: item['@_Date'] || 'Unknown',
          type: item['@_Type'] || 'Unknown',
          purpose: item['@_InquiryPurposeType'] || 'Unknown'
        };
      }
      
      const itemText = JSON.stringify(itemSummary);
      const itemTokens = countTokens(itemText);
      
      if (itemTokens > TOKENS_PER_ACCOUNT_LIMIT) {
        console.log(`🚨 ${itemType.toUpperCase()} SKIPPED: ${itemId} has ${itemTokens} tokens`);
        accountsSkippedByTokens++;
        const fallbackViolations = itemType === 'account' ? 
          getStaticViolationsForAccount(item, itemIndex) :
          getStaticViolationsForItem(item, itemType, itemIndex);
        return { itemId, violations: fallbackViolations };
      }
      
      console.log(`🔍 Analyzing ${itemType} ${itemId} with OpenAI (parallel)...`);
      
      // Create type-specific system prompt
      let systemPrompt: string;
      if (itemType === 'account') {
        systemPrompt = `You are an expert credit compliance analyst. Analyze this credit account for Metro 2, FCRA, and FDCPA violations. Return exactly 3 violations in this format:
          - Metro 2 Violation: [specific violation]
          - FCRA Violation: [specific violation] 
          - FDCPA Violation: [specific violation]`;
      } else if (itemType === 'public_record') {
        systemPrompt = `You are an expert credit compliance analyst. Analyze this public record for Metro 2, FCRA, and FDCPA violations. Return exactly 3 violations in this format:
          - Metro 2 Violation: [specific violation]
          - FCRA Violation: [specific violation] 
          - FDCPA Violation: [specific violation]`;
      } else {
        systemPrompt = `You are an expert credit compliance analyst. Analyze this credit inquiry for Metro 2, FCRA, and FDCPA violations. Return exactly 3 violations in this format:
          - Metro 2 Violation: [specific violation]
          - FCRA Violation: [specific violation] 
          - FDCPA Violation: [specific violation]`;
      }
      
      // OPTIMIZED: Use GPT-3.5-turbo-1106 instead of GPT-4
      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo-1106",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: `Analyze this ${itemType} for compliance violations: ${itemText}`
          }
        ],
        max_tokens: MAX_TOKENS_RESPONSE,
        temperature: 0.3
      });

      const response = completion.choices[0]?.message?.content;
      console.log(`🤖 OpenAI RAW RESPONSE for ${itemId}:`, response);
      
      if (response) {
        const detectedViolations = response.split('\n')
          .filter(line => line.trim().length > 0)
          .slice(0, 3)
          .map(line => line.trim());
        
        console.log(`✅ OpenAI detected ${detectedViolations.length} violations for ${itemId}`);
        accountsAnalyzedWithAI++;
        
        return { 
          itemId, 
          violations: detectedViolations.length > 0 ? detectedViolations : 
            (itemType === 'account' ? 
              getStaticViolationsForAccount(item, itemIndex) :
              getStaticViolationsForItem(item, itemType, itemIndex))
        };
      } else {
        console.log(`⚠️ OpenAI returned empty response for ${itemId}, using fallback`);
        const fallbackViolations = itemType === 'account' ? 
          getStaticViolationsForAccount(item, itemIndex) :
          getStaticViolationsForItem(item, itemType, itemIndex);
        return { itemId, violations: fallbackViolations };
      }

    } catch (error: any) {
      console.error(`🚨 AI analysis failed for ${itemType} ${itemId}:`, error.message);
      const fallbackViolations = itemType === 'account' ? 
        getStaticViolationsForAccount(item, itemIndex) :
        getStaticViolationsForItem(item, itemType, itemIndex);
      return { itemId, violations: fallbackViolations };
    }
  };

  // OPTIMIZED: Process items with concurrency limit using Promise.all
  const processInBatches = async (items: any[], batchSize: number) => {
    const results: { itemId: string, violations: string[] }[] = [];
    
    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);
      const progressPercent = 30 + (i / items.length) * 50;
      sendProgress(progressPercent, `Processing batch ${Math.floor(i / batchSize) + 1} of ${Math.ceil(items.length / batchSize)} (${batch.length} items)...`);
      
      console.log(`🔄 PARALLEL BATCH ${Math.floor(i / batchSize) + 1}: Processing ${batch.length} items concurrently`);
      
      const batchResults = await Promise.all(
        batch.map((item, batchIndex) => processItemWithAI(item, i + batchIndex))
      );
      
      results.push(...batchResults);
      console.log(`✅ BATCH ${Math.floor(i / batchSize) + 1} COMPLETE: ${batchResults.length} items processed`);
    }
    
    return results;
  };

  // Execute parallel processing with concurrency limit
  const results = await processInBatches(allItemsToProcess, MAX_CONCURRENT_REQUESTS);
  
  // Collect all violations from results
  results.forEach(result => {
    violations[result.itemId] = result.violations;
    totalAccountsProcessed++;
  });

  console.log(`🎯 PARALLEL PROCESSING COMPLETE: ${results.length} items processed`);
  sendProgress(80, "Finalizing analysis...");

  // Add any remaining public records that weren't processed
  const remainingPublicRecords = creditData?.CREDIT_RESPONSE?.PUBLIC_RECORD;
  if (remainingPublicRecords && Array.isArray(remainingPublicRecords) && remainingPublicRecords.length > 0) {
    remainingPublicRecords.forEach((record: any, index: number) => {
      const recordId = record["@_AccountIdentifier"] || `PUBLIC-RECORD-${String(index + 1).padStart(3, '0')}`;
      if (!violations[recordId]) {
        violations[recordId] = getStaticPublicRecordViolations(index);
      }
    });
  }

  sendProgress(90, "Finalizing analysis...");

  const totalViolations = Object.values(violations).flat().length;
  const affectedItems = Object.keys(violations).length;

  // Calculate breakdown by category
  const accountViolations = Object.keys(violations).filter(id => id.startsWith('TRADE')).length;
  const publicRecordViolations = Object.keys(violations).filter(id => id.includes('PUBLIC-RECORD')).length;
  const inquiryViolations = Object.keys(violations).filter(id => id.includes('INQUIRY')).length;

  console.log(`✅ AI Scan completed: ${totalViolations} violations found`);
  console.log(`📊 Breakdown: ${accountViolations} accounts, ${publicRecordViolations} public records, ${inquiryViolations} inquiries`);
  console.log(`📊 Items analyzed with AI: ${accountsAnalyzedWithAI}`);
  console.log(`📊 Items skipped by tokens: ${accountsSkippedByTokens}`);
  console.log(`📊 Total items processed: ${totalAccountsProcessed}`);

  return {
    success: true,
    totalViolations,
    affectedAccounts: affectedItems,
    violations,
    breakdown: {
      accounts: accountViolations,
      publicRecords: publicRecordViolations,
      inquiries: inquiryViolations
    },
    message: `AI analysis completed: Found violations across ${accountViolations} accounts, ${publicRecordViolations} public records, and ${inquiryViolations} inquiries`,
    tokenInfo: {
      inputTokens: totalInputTokens,
      itemsAnalyzedWithAI: accountsAnalyzedWithAI,
      itemsSkippedByTokens: accountsSkippedByTokens,
      totalItemsProcessed: totalAccountsProcessed,
      fallbackUsed: false
    }
  };
}

// Helper function for static violations
function generateStaticViolations(creditData: any): { [key: string]: string[] } {
  const violations: { [key: string]: string[] } = {};
  
  // Add some default violations for testing
  const testAccounts = ["TRADE001", "TRADE002", "TRADE003"];
  testAccounts.forEach((accountId, index) => {
    violations[accountId] = getStaticViolationsForAccount({}, index);
  });
  
  return violations;
}

export function registerOptimizedRoutes(app: Express): void {
  
  // OPTIMIZED: POST endpoint for AI scan with parallel processing
  app.post('/api/ai-scan', async (req: Request, res: Response) => {
    console.log("🔍 POST /api/ai-scan endpoint called with optimized parallel processing");
    
    try {
      const creditData = req.body;
      console.log("📨 Received credit data for AI scan analysis");
      
      // Dummy progress function for POST endpoint
      const sendProgress = (progress: number, message: string) => {
        console.log(`📊 Progress: ${progress}% - ${message}`);
      };
      
      const result = await performAiScan(creditData, sendProgress);
      
      console.log("✅ AI scan completed successfully");
      res.json(result);
      
    } catch (error: any) {
      console.error("🚨 AI scan failed:", error.message);
      
      if (error.message.includes('INPUT_TOO_LARGE')) {
        res.status(413).json({
          success: false,
          error: 'INPUT_TOO_LARGE',
          message: 'Credit data is too large for AI analysis. Using static violations instead.',
          fallbackUsed: true
        });
      } else if (error.message.includes('insufficient_quota')) {
        res.status(429).json({
          success: false,
          error: 'QUOTA_EXCEEDED',
          message: 'OpenAI API quota exceeded. Using static violations instead.',
          fallbackUsed: true
        });
      } else {
        res.status(500).json({
          success: false,
          error: 'AI_SCAN_FAILED',
          message: 'AI scan failed. Using static violations instead.',
          fallbackUsed: true
        });
      }
    }
  });
}